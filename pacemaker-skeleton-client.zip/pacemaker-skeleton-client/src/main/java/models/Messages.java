package models;

import static com.google.common.base.MoreObjects.toStringHelper;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import com.google.common.base.Objects;

public class Messages implements Serializable {

  public String id;
  public String sentby;
  public String message;
  

  //public List<Location> route = new ArrayList<>();

  public Messages() {
  }

  public Messages(String sentby, String message) {
    this.id = UUID.randomUUID().toString();
    this.sentby = sentby;
    this.message = message;
    
  }

  public String getId() {
    return id;
  }

  public String getSentby() {
    return sentby;
  }

  public String getMessage() {
    return message;
  }

  

  @Override
  public boolean equals(final Object obj) {
    if (obj instanceof Messages) {
      final Messages other = (Messages) obj;
      return Objects.equal(sentby, other.sentby)
          && Objects.equal(message, other.message);
    } else {
      return false;
    }
  }

  @Override
  public String toString() {
    return toStringHelper(this).addValue(id)
        .addValue(sentby)
        .addValue(message)
        .toString();
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(this.id, this.sentby, this.message);
  }
}