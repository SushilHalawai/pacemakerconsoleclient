package models;

import static com.google.common.base.MoreObjects.toStringHelper;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import com.google.common.base.Objects;

public class FriendsActivities implements Serializable {

  public String id;
  public String email;
  public String type;
  public String location;
  public double distance;

  //public List<Location> route = new ArrayList<>();

  public FriendsActivities() {
  }

  public FriendsActivities(String id,String email,String type, String location, double distance) {
    //this.id = UUID.randomUUID().toString();
	this.id=id;
    this.email=email;
    this.type = type;
    this.location = location;
    this.distance = distance;
  }

  public String getId() {
    return id;
  }
  
  public String getEmail() {
	    return email;
	  }

  public String getType() {
    return type;
  }

  public String getLocation() {
    return location;
  }

  public String getDistance() {
    return Double.toString(distance);
  }

  //public String getRoute() {
   // return route.toString();
  //}

  @Override
  public boolean equals(final Object obj) {
    if (obj instanceof FriendsActivities) {
      final FriendsActivities other = (FriendsActivities) obj;
      return Objects.equal(email, other.email)
    		&&  Objects.equal(type, other.type)
          && Objects.equal(location, other.location)
          && Objects.equal(distance, other.distance);
          //&& Objects.equal(route, other.route);
    } else {
      return false;
    }
  }

  @Override
  public String toString() {
    return toStringHelper(this).addValue(id)
    	.addValue(email)
        .addValue(type)
        .addValue(location)
        .addValue(distance)
        //.addValue(route)
        .toString();
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(this.id, this.email, this.type, this.location, this.distance);
  }
}