package parsers;

import java.util.Collection;
import java.util.List;
import models.Activity;
import models.FriendsActivities;
import models.Location;
import models.Messages;
import models.User;

public class Parser {

  public void println(String s) {
    System.out.println(s);
  }

  public void renderUser(User user) {
    System.out.println(user.toString());
  }

  public void renderUsers(Collection<User> users) {
    System.out.println(users.toString());
  }

  public void renderActivity(Activity activities) {
    System.out.println(activities.toString());
  }

  public void renderActivities(Collection<Activity> activities) {
    System.out.println(activities.toString());
  }
  
  public void renderMessage(Collection<Messages> messages) {
	    System.out.println(messages.toString());
	  }
  
  
  public void renderFriendsActivities(Collection<FriendsActivities> friendsactivities) {
	    System.out.println(friendsactivities.toString());
	  }
  
  
  public void renderSentMessage(Messages messages) {
	    System.out.println(messages.toString());
	  }

  public void renderLocations(List<Location> locations) {
    System.out.println(locations.toString());
  }


}