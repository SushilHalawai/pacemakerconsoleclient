package parsers;

import com.bethecoder.ascii_table.ASCIITable;
import com.bethecoder.ascii_table.impl.CollectionASCIITableAware;
import com.bethecoder.ascii_table.spec.IASCIITableAware;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import models.Activity;
import models.FriendsActivities;
import models.Location;
import models.Messages;
import models.User;

public class AsciiTableParser extends Parser {

  public void renderUser(User user) {
    if (user != null) {
      renderUsers(Arrays.asList(user));
      System.out.println("ok");
    } else {
      System.out.println("not found");
    }
  }

  public void renderUsers(Collection<User> users) {
    if (users != null) {
      if (!users.isEmpty()) {
        List<User> userList = new ArrayList<User>(users);
        IASCIITableAware asciiTableAware = new CollectionASCIITableAware<User>(userList, "id",
            "firstname",
            "lastname", "email");
        System.out.println(ASCIITable.getInstance().getTable(asciiTableAware));
      }
      System.out.println("ok");
    } else {
      System.out.println("not found");
    }
  }

  public void renderActivity(Activity activity) {
    if (activity != null) {
      renderActivities(Arrays.asList(activity));
      System.out.println("ok");
    } else {
      System.out.println("not found");
    }
  }
  
  public void renderSentMessage(Messages message) {
	    if (message != null) {
	      renderMessage(Arrays.asList(message));
	      System.out.println("ok");
	    } else {
	      System.out.println("not found");
	    }
	  }

  /*public void renderActivities(Collection<Activity> activities) {
    if (activities != null) {
      if (!activities.isEmpty()) {
        List<Activity> activityList = new ArrayList(activities);
        IASCIITableAware asciiTableAware = new CollectionASCIITableAware<Activity>(activityList,
            "id",
            "type", "location", "distance", "starttime", "duration");
        System.out.println(ASCIITable.getInstance().getTable(asciiTableAware));
      }
      System.out.println("ok");
    } else {
      System.out.println("not found");
    }
  }*/
  //removed starttime and duration
  public void renderActivities(Collection<Activity> activities) {
	    if (activities != null) {
	      if (!activities.isEmpty()) {
	        List<Activity> activityList = new ArrayList(activities);
	        IASCIITableAware asciiTableAware = new CollectionASCIITableAware<Activity>(activityList,
	            "id",
	            "type", "location", "distance");
	        System.out.println(ASCIITable.getInstance().getTable(asciiTableAware));
	      }
	      System.out.println("ok");
	    } else {
	      System.out.println("not found");
	    }
	  }
  
  
  public void renderFriendsActivities(Collection<FriendsActivities> friendsactivities) {
	    if (friendsactivities != null) {
	      if (!friendsactivities.isEmpty()) {
	        List<FriendsActivities> friendsactivitiesList = new ArrayList(friendsactivities);
	        IASCIITableAware asciiTableAware = new CollectionASCIITableAware<FriendsActivities>(friendsactivitiesList,
	            "id","email","type", "location", "distance");
	        System.out.println(ASCIITable.getInstance().getTable(asciiTableAware));
	      }
	      System.out.println("ok");
	    } else {
	      System.out.println("not found");
	    }
	  }

  public void renderMessage(Collection<Messages> messages) {
	    if (messages != null) {
	      if (!messages.isEmpty()) {
	        List<Messages> messageList = new ArrayList(messages);
	        IASCIITableAware asciiTableAware = new CollectionASCIITableAware<Messages>(messageList,
	            "id",
	            "sentby", "message");
	        System.out.println(ASCIITable.getInstance().getTable(asciiTableAware));
	      }
	      System.out.println("ok");
	    } else {
	      System.out.println("not found");
	    }
	  }

  public void renderLocations(List<Location> locations) {
	  
	  //Integer i = 1;
    if (locations != null) {
      if (!locations.isEmpty()) {
    	 // i=1+i;
        IASCIITableAware asciiTableAware = new CollectionASCIITableAware<Location>(locations,
            "id",
            "latitude", "longitude");
        System.out.println(ASCIITable.getInstance().getTable(asciiTableAware));
      }
      System.out.println("ok");
    } else {
      System.out.println("not found");
    }
  }
}